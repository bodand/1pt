CREATE VIEW pg_cursors(name, statement, is_holdable, is_binary, is_scrollable, creation_time) AS
SELECT name
     , statement
     , is_holdable
     , is_binary
     , is_scrollable
     , creation_time
  FROM pg_cursor() c(name, statement, is_holdable, is_binary, is_scrollable, creation_time);

ALTER TABLE pg_cursors
    OWNER TO postgres;

GRANT SELECT ON pg_cursors TO PUBLIC;

