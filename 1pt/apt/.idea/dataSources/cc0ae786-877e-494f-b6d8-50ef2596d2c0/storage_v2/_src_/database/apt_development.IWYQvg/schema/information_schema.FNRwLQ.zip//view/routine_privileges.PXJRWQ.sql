CREATE VIEW routine_privileges
            (grantor, grantee, specific_catalog, specific_schema, specific_name, routine_catalog, routine_schema,
             routine_name, privilege_type, is_grantable)
AS
SELECT u_grantor.rolname::information_schema.sql_identifier               grantor
     , grantee.rolname::information_schema.sql_identifier                 grantee
     , CURRENT_DATABASE()::information_schema.sql_identifier              specific_catalog
     , n.nspname::information_schema.sql_identifier                       specific_schema
     , nameconcatoid(p.proname, p.oid)::information_schema.sql_identifier specific_name
     , CURRENT_DATABASE()::information_schema.sql_identifier              routine_catalog
     , n.nspname::information_schema.sql_identifier                       routine_schema
     , p.proname::information_schema.sql_identifier                       routine_name
     , 'EXECUTE'::CHARACTER VARYING::information_schema.character_data    privilege_type
     , CASE
           WHEN PG_HAS_ROLE(grantee.oid, p.proowner, 'USAGE'::TEXT) OR p.grantable THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
    END::information_schema.yes_or_no                                     is_grantable
  FROM ( SELECT pg_proc.oid
              , pg_proc.proname
              , pg_proc.proowner
              , pg_proc.pronamespace
              , (aclexplode(COALESCE(pg_proc.proacl, acldefault('f'::"char", pg_proc.proowner)))).grantor grantor
              , (aclexplode(COALESCE(pg_proc.proacl, acldefault('f'::"char", pg_proc.proowner)))).grantee grantee
              , (aclexplode(COALESCE(pg_proc.proacl,
                                     acldefault('f'::"char", pg_proc.proowner)))).privilege_type          privilege_type
              , (aclexplode(COALESCE(pg_proc.proacl,
                                     acldefault('f'::"char", pg_proc.proowner)))).is_grantable            is_grantable
           FROM pg_proc
       ) p(oid, proname, proowner, pronamespace, grantor, grantee, prtype, grantable)
     , pg_namespace n
     , pg_authid u_grantor
     , ( SELECT pg_authid.oid
              , pg_authid.rolname
           FROM pg_authid
          UNION ALL
         SELECT 0::oid oid
              , 'PUBLIC'::name
       ) grantee(oid, rolname)
 WHERE p.pronamespace = n.oid
   AND grantee.oid = p.grantee
   AND u_grantor.oid = p.grantor
   AND p.prtype = 'EXECUTE'::TEXT
   AND (PG_HAS_ROLE(u_grantor.oid, 'USAGE'::TEXT) OR PG_HAS_ROLE(grantee.oid, 'USAGE'::TEXT) OR
        grantee.rolname = 'PUBLIC'::name);

ALTER TABLE routine_privileges
    OWNER TO postgres;

GRANT SELECT ON routine_privileges TO PUBLIC;

