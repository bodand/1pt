CREATE VIEW pg_user_mappings(umid, srvid, srvname, umuser, usename, umoptions) AS
SELECT u.oid umid
     , s.oid srvid
     , s.srvname
     , u.umuser
     , CASE
           WHEN u.umuser = 0::oid THEN 'public'::name
           ELSE a.rolname
    END      usename
     , CASE
           WHEN u.umuser <> 0::oid AND a.rolname = CURRENT_USER AND
                (PG_HAS_ROLE(s.srvowner, 'USAGE'::TEXT) OR HAS_SERVER_PRIVILEGE(s.oid, 'USAGE'::TEXT)) OR
                u.umuser = 0::oid AND PG_HAS_ROLE(s.srvowner, 'USAGE'::TEXT) OR ( SELECT pg_authid.rolsuper
                                                                                    FROM pg_authid
                                                                                   WHERE pg_authid.rolname = CURRENT_USER
                                                                                ) THEN u.umoptions
           ELSE NULL::TEXT[]
    END      umoptions
  FROM pg_user_mapping u
           JOIN pg_foreign_server s ON u.umserver = s.oid
           LEFT JOIN pg_authid a ON a.oid = u.umuser;

ALTER TABLE pg_user_mappings
    OWNER TO postgres;

GRANT SELECT ON pg_user_mappings TO PUBLIC;

