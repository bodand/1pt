CREATE VIEW triggers
            (trigger_catalog, trigger_schema, trigger_name, event_manipulation, event_object_catalog,
             event_object_schema, event_object_table, action_order, action_condition, action_statement,
             action_orientation, action_timing, action_reference_old_table, action_reference_new_table,
             action_reference_old_row, action_reference_new_row, created)
AS
SELECT CURRENT_DATABASE()::information_schema.sql_identifier                                                                                                                                                                               trigger_catalog
     , n.nspname::information_schema.sql_identifier                                                                                                                                                                                        trigger_schema
     , t.tgname::information_schema.sql_identifier                                                                                                                                                                                         trigger_name
     , em.text::information_schema.character_data                                                                                                                                                                                          event_manipulation
     , CURRENT_DATABASE()::information_schema.sql_identifier                                                                                                                                                                               event_object_catalog
     , n.nspname::information_schema.sql_identifier                                                                                                                                                                                        event_object_schema
     , c.relname::information_schema.sql_identifier                                                                                                                                                                                        event_object_table
     , RANK()
       OVER (PARTITION BY (n.nspname::information_schema.sql_identifier), (c.relname::information_schema.sql_identifier), em.num, (t.tgtype::INTEGER & 1), (t.tgtype::INTEGER & 66) ORDER BY t.tgname)::information_schema.cardinal_number action_order
     , CASE
           WHEN PG_HAS_ROLE(c.relowner, 'USAGE'::TEXT) THEN (REGEXP_MATCH(PG_GET_TRIGGERDEF(t.oid),
                                                                          '.{35,} WHEN \((.+)\) EXECUTE FUNCTION'::TEXT))[1]
           ELSE NULL::TEXT
    END::information_schema.character_data                                                                                                                                                                                                 action_condition
     , SUBSTRING(PG_GET_TRIGGERDEF(t.oid) FROM
                 POSITION(('EXECUTE FUNCTION'::TEXT) IN (SUBSTRING(PG_GET_TRIGGERDEF(t.oid) FROM 48))) +
                 47)::information_schema.character_data                                                                                                                                                                                    action_statement
     , CASE t.tgtype::INTEGER & 1
           WHEN 1 THEN 'ROW'::TEXT
           ELSE 'STATEMENT'::TEXT
    END::information_schema.character_data                                                                                                                                                                                                 action_orientation
     , CASE t.tgtype::INTEGER & 66
           WHEN 2 THEN 'BEFORE'::TEXT
           WHEN 64 THEN 'INSTEAD OF'::TEXT
           ELSE 'AFTER'::TEXT
    END::information_schema.character_data                                                                                                                                                                                                 action_timing
     , t.tgoldtable::information_schema.sql_identifier                                                                                                                                                                                     action_reference_old_table
     , t.tgnewtable::information_schema.sql_identifier                                                                                                                                                                                     action_reference_new_table
     , NULL::name::information_schema.sql_identifier                                                                                                                                                                                       action_reference_old_row
     , NULL::name::information_schema.sql_identifier                                                                                                                                                                                       action_reference_new_row
     , NULL::TIMESTAMP WITH TIME ZONE::information_schema.time_stamp                                                                                                                                                                       created
  FROM pg_namespace n
     , pg_class c
     , pg_trigger t
     , ( VALUES (4, 'INSERT'::TEXT), (8, 'DELETE'::TEXT), (16, 'UPDATE'::TEXT) ) em(num, text)
 WHERE n.oid = c.relnamespace
   AND c.oid = t.tgrelid
   AND (t.tgtype::INTEGER & em.num) <> 0
   AND NOT t.tgisinternal
   AND NOT PG_IS_OTHER_TEMP_SCHEMA(n.oid)
   AND (PG_HAS_ROLE(c.relowner, 'USAGE'::TEXT) OR
        HAS_TABLE_PRIVILEGE(c.oid, 'INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER'::TEXT) OR
        HAS_ANY_COLUMN_PRIVILEGE(c.oid, 'INSERT, UPDATE, REFERENCES'::TEXT));

ALTER TABLE triggers
    OWNER TO postgres;

GRANT SELECT ON triggers TO PUBLIC;

