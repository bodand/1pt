CREATE VIEW udt_privileges (grantor, grantee, udt_catalog, udt_schema, udt_name, privilege_type, is_grantable) AS
SELECT u_grantor.rolname::information_schema.sql_identifier               grantor
     , grantee.rolname::information_schema.sql_identifier                 grantee
     , CURRENT_DATABASE()::information_schema.sql_identifier              udt_catalog
     , n.nspname::information_schema.sql_identifier                       udt_schema
     , t.typname::information_schema.sql_identifier                       udt_name
     , 'TYPE USAGE'::CHARACTER VARYING::information_schema.character_data privilege_type
     , CASE
           WHEN PG_HAS_ROLE(grantee.oid, t.typowner, 'USAGE'::TEXT) OR t.grantable THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
    END::information_schema.yes_or_no                                     is_grantable
  FROM ( SELECT pg_type.oid
              , pg_type.typname
              , pg_type.typnamespace
              , pg_type.typtype
              , pg_type.typowner
              , (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantor grantor
              , (aclexplode(COALESCE(pg_type.typacl, acldefault('T'::"char", pg_type.typowner)))).grantee grantee
              , (aclexplode(COALESCE(pg_type.typacl,
                                     acldefault('T'::"char", pg_type.typowner)))).privilege_type          privilege_type
              , (aclexplode(COALESCE(pg_type.typacl,
                                     acldefault('T'::"char", pg_type.typowner)))).is_grantable            is_grantable
           FROM pg_type
       ) t(oid, typname, typnamespace, typtype, typowner, grantor, grantee, prtype, grantable)
     , pg_namespace n
     , pg_authid u_grantor
     , ( SELECT pg_authid.oid
              , pg_authid.rolname
           FROM pg_authid
          UNION ALL
         SELECT 0::oid oid
              , 'PUBLIC'::name
       ) grantee(oid, rolname)
 WHERE t.typnamespace = n.oid
   AND t.typtype = 'c'::"char"
   AND t.grantee = grantee.oid
   AND t.grantor = u_grantor.oid
   AND t.prtype = 'USAGE'::TEXT
   AND (PG_HAS_ROLE(u_grantor.oid, 'USAGE'::TEXT) OR PG_HAS_ROLE(grantee.oid, 'USAGE'::TEXT) OR
        grantee.rolname = 'PUBLIC'::name);

ALTER TABLE udt_privileges
    OWNER TO postgres;

GRANT SELECT ON udt_privileges TO PUBLIC;

