CREATE VIEW pg_user (usename, usesysid, usecreatedb, usesuper, userepl, usebypassrls, passwd, valuntil, useconfig) AS
SELECT usename
     , usesysid
     , usecreatedb
     , usesuper
     , userepl
     , usebypassrls
     , '********'::TEXT passwd
     , valuntil
     , useconfig
  FROM pg_shadow;

ALTER TABLE pg_user
    OWNER TO postgres;

GRANT SELECT ON pg_user TO PUBLIC;

