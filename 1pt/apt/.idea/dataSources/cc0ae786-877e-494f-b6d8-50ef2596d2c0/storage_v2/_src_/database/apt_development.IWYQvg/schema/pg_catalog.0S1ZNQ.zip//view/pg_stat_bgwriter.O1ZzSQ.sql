CREATE VIEW pg_stat_bgwriter
            (checkpoints_timed, checkpoints_req, checkpoint_write_time, checkpoint_sync_time, buffers_checkpoint,
             buffers_clean, maxwritten_clean, buffers_backend, buffers_backend_fsync, buffers_alloc, stats_reset)
AS
SELECT pg_stat_get_bgwriter_timed_checkpoints()       checkpoints_timed
     , pg_stat_get_bgwriter_requested_checkpoints()   checkpoints_req
     , pg_stat_get_checkpoint_write_time()            checkpoint_write_time
     , pg_stat_get_checkpoint_sync_time()             checkpoint_sync_time
     , pg_stat_get_bgwriter_buf_written_checkpoints() buffers_checkpoint
     , pg_stat_get_bgwriter_buf_written_clean()       buffers_clean
     , pg_stat_get_bgwriter_maxwritten_clean()        maxwritten_clean
     , pg_stat_get_buf_written_backend()              buffers_backend
     , pg_stat_get_buf_fsync_backend()                buffers_backend_fsync
     , pg_stat_get_buf_alloc()                        buffers_alloc
     , pg_stat_get_bgwriter_stat_reset_time()         stats_reset;

ALTER TABLE pg_stat_bgwriter
    OWNER TO postgres;

GRANT SELECT ON pg_stat_bgwriter TO PUBLIC;

