CREATE VIEW pg_views(schemaname, viewname, viewowner, definition) AS
SELECT n.nspname                   schemaname
     , c.relname                   viewname
     , PG_GET_USERBYID(c.relowner) viewowner
     , PG_GET_VIEWDEF(c.oid)       definition
  FROM pg_class c
           LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE c.relkind = 'v'::"char";

ALTER TABLE pg_views
    OWNER TO postgres;

GRANT SELECT ON pg_views TO PUBLIC;

