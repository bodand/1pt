CREATE FUNCTION timedate_pl(time without time zone, date) RETURNS timestamp without time zone
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN ($2 + $1);

COMMENT ON FUNCTION timedate_pl(TIME, DATE) IS 'implementation of + operator';

ALTER FUNCTION timedate_pl(TIME, DATE) OWNER TO postgres;

