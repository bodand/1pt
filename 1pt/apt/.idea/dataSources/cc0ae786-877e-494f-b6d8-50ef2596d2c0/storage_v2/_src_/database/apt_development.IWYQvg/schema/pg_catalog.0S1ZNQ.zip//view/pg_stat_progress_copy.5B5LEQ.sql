CREATE VIEW pg_stat_progress_copy
            (pid, datid, datname, relid, command, type, bytes_processed, bytes_total, tuples_processed,
             tuples_excluded) AS
SELECT s.pid
     , s.datid
     , d.datname
     , s.relid
     , CASE s.param5
           WHEN 1 THEN 'COPY FROM'::TEXT
           WHEN 2 THEN 'COPY TO'::TEXT
           ELSE NULL::TEXT
    END         command
     , CASE s.param6
           WHEN 1 THEN 'FILE'::TEXT
           WHEN 2 THEN 'PROGRAM'::TEXT
           WHEN 3 THEN 'PIPE'::TEXT
           WHEN 4 THEN 'CALLBACK'::TEXT
           ELSE NULL::TEXT
    END         type
     , s.param1 bytes_processed
     , s.param2 bytes_total
     , s.param3 tuples_processed
     , s.param4 tuples_excluded
  FROM pg_stat_get_progress_info('COPY'::TEXT) s(pid, datid, relid, param1, param2, param3, param4, param5, param6,
                                                 param7, param8, param9, param10, param11, param12, param13, param14,
                                                 param15, param16, param17, param18, param19, param20)
           LEFT JOIN pg_database d ON s.datid = d.oid;

ALTER TABLE pg_stat_progress_copy
    OWNER TO postgres;

GRANT SELECT ON pg_stat_progress_copy TO PUBLIC;

