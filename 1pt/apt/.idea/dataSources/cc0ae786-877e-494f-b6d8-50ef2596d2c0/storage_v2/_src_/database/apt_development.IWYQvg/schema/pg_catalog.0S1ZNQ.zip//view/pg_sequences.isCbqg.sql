CREATE VIEW pg_sequences
            (schemaname, sequencename, sequenceowner, data_type, start_value, min_value, max_value, increment_by, cycle,
             cache_size, last_value)
AS
SELECT n.nspname                   schemaname
     , c.relname                   sequencename
     , PG_GET_USERBYID(c.relowner) sequenceowner
     , s.seqtypid::regtype         data_type
     , s.seqstart                  start_value
     , s.seqmin                    min_value
     , s.seqmax                    max_value
     , s.seqincrement              increment_by
     , s.seqcycle                  cycle
     , s.seqcache                  cache_size
     , CASE
           WHEN HAS_SEQUENCE_PRIVILEGE(c.oid, 'SELECT,USAGE'::TEXT) THEN pg_sequence_last_value(c.oid::regclass)
           ELSE NULL::BIGINT
    END                            last_value
  FROM pg_sequence s
           JOIN pg_class c ON c.oid = s.seqrelid
           LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE NOT PG_IS_OTHER_TEMP_SCHEMA(n.oid)
   AND c.relkind = 'S'::"char";

ALTER TABLE pg_sequences
    OWNER TO postgres;

GRANT SELECT ON pg_sequences TO PUBLIC;

