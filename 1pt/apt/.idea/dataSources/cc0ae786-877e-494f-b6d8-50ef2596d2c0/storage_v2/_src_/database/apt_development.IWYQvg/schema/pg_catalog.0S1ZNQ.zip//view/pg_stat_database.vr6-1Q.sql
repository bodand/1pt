CREATE VIEW pg_stat_database
            (datid, datname, numbackends, xact_commit, xact_rollback, blks_read, blks_hit, tup_returned, tup_fetched,
             tup_inserted, tup_updated, tup_deleted, conflicts, temp_files, temp_bytes, deadlocks, checksum_failures,
             checksum_last_failure, blk_read_time, blk_write_time, session_time, active_time, idle_in_transaction_time,
             sessions, sessions_abandoned, sessions_fatal, sessions_killed, stats_reset)
AS
SELECT oid                                                                 datid
     , datname
     , CASE
           WHEN oid = 0::oid THEN 0
           ELSE pg_stat_get_db_numbackends(oid)
    END                                                                    numbackends
     , pg_stat_get_db_xact_commit(oid)                                     xact_commit
     , pg_stat_get_db_xact_rollback(oid)                                   xact_rollback
     , pg_stat_get_db_blocks_fetched(oid) - pg_stat_get_db_blocks_hit(oid) blks_read
     , pg_stat_get_db_blocks_hit(oid)                                      blks_hit
     , pg_stat_get_db_tuples_returned(oid)                                 tup_returned
     , pg_stat_get_db_tuples_fetched(oid)                                  tup_fetched
     , pg_stat_get_db_tuples_inserted(oid)                                 tup_inserted
     , pg_stat_get_db_tuples_updated(oid)                                  tup_updated
     , pg_stat_get_db_tuples_deleted(oid)                                  tup_deleted
     , pg_stat_get_db_conflict_all(oid)                                    conflicts
     , pg_stat_get_db_temp_files(oid)                                      temp_files
     , pg_stat_get_db_temp_bytes(oid)                                      temp_bytes
     , pg_stat_get_db_deadlocks(oid)                                       deadlocks
     , pg_stat_get_db_checksum_failures(oid)                               checksum_failures
     , pg_stat_get_db_checksum_last_failure(oid)                           checksum_last_failure
     , pg_stat_get_db_blk_read_time(oid)                                   blk_read_time
     , pg_stat_get_db_blk_write_time(oid)                                  blk_write_time
     , pg_stat_get_db_session_time(oid)                                    session_time
     , pg_stat_get_db_active_time(oid)                                     active_time
     , pg_stat_get_db_idle_in_transaction_time(oid)                        idle_in_transaction_time
     , pg_stat_get_db_sessions(oid)                                        sessions
     , pg_stat_get_db_sessions_abandoned(oid)                              sessions_abandoned
     , pg_stat_get_db_sessions_fatal(oid)                                  sessions_fatal
     , pg_stat_get_db_sessions_killed(oid)                                 sessions_killed
     , pg_stat_get_db_stat_reset_time(oid)                                 stats_reset
  FROM ( SELECT 0          oid
              , NULL::name datname
          UNION ALL
         SELECT pg_database.oid
              , pg_database.datname
           FROM pg_database
       ) d;

ALTER TABLE pg_stat_database
    OWNER TO postgres;

GRANT SELECT ON pg_stat_database TO PUBLIC;

