CREATE VIEW pg_publication_tables(pubname, schemaname, tablename, attnames, rowfilter) AS
SELECT p.pubname
     , n.nspname                        schemaname
     , c.relname                        tablename
     , ( SELECT ARRAY_AGG(a.attname ORDER BY a.attnum) array_agg
           FROM pg_attribute a
          WHERE a.attrelid = gpt.relid
            AND (a.attnum = ANY (gpt.attrs::SMALLINT[]))
       )                                attnames
     , PG_GET_EXPR(gpt.qual, gpt.relid) rowfilter
  FROM pg_publication p
     , LATERAL pg_get_publication_tables(VARIADIC ARRAY [p.pubname::TEXT]) gpt(pubid, relid, attrs, qual)
     , pg_class c
           JOIN pg_namespace n ON n.oid = c.relnamespace
 WHERE c.oid = gpt.relid;

ALTER TABLE pg_publication_tables
    OWNER TO postgres;

GRANT SELECT ON pg_publication_tables TO PUBLIC;

