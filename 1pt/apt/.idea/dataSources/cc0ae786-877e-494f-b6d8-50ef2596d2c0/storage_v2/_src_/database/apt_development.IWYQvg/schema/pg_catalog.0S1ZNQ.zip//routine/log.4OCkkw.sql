CREATE FUNCTION log(numeric) RETURNS numeric
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN log((10)::numeric, $1);

COMMENT ON FUNCTION log(NUMERIC) IS 'base 10 logarithm';

ALTER FUNCTION log(NUMERIC) OWNER TO postgres;

