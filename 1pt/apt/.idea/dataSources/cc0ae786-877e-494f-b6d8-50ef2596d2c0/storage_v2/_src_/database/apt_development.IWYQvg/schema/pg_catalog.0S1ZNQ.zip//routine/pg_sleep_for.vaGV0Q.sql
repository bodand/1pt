CREATE FUNCTION pg_sleep_for(interval) RETURNS void
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN pg_sleep(((EXTRACT(epoch FROM (clock_timestamp() + $1)) - EXTRACT(epoch FROM clock_timestamp())))::double precision);

COMMENT ON FUNCTION pg_sleep_for(INTERVAL) IS 'sleep for the specified interval';

ALTER FUNCTION pg_sleep_for(INTERVAL) OWNER TO postgres;

