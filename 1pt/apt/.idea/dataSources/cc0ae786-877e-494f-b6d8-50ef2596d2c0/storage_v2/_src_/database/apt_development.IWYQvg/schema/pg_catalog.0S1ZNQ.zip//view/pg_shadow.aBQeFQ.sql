CREATE VIEW pg_shadow (usename, usesysid, usecreatedb, usesuper, userepl, usebypassrls, passwd, valuntil, useconfig) AS
SELECT pg_authid.rolname        usename
     , pg_authid.oid            usesysid
     , pg_authid.rolcreatedb    usecreatedb
     , pg_authid.rolsuper       usesuper
     , pg_authid.rolreplication userepl
     , pg_authid.rolbypassrls   usebypassrls
     , pg_authid.rolpassword    passwd
     , pg_authid.rolvaliduntil  valuntil
     , s.setconfig              useconfig
  FROM pg_authid
           LEFT JOIN pg_db_role_setting s ON pg_authid.oid = s.setrole AND s.setdatabase = 0::oid
 WHERE pg_authid.rolcanlogin;

ALTER TABLE pg_shadow
    OWNER TO postgres;

