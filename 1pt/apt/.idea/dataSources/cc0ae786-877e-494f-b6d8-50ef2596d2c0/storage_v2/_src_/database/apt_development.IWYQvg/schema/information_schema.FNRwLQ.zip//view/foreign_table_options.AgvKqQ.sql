CREATE VIEW foreign_table_options
            (foreign_table_catalog, foreign_table_schema, foreign_table_name, option_name, option_value) AS
SELECT foreign_table_catalog
     , foreign_table_schema
     , foreign_table_name
     , (PG_OPTIONS_TO_TABLE(ftoptions)).option_name::information_schema.sql_identifier  option_name
     , (PG_OPTIONS_TO_TABLE(ftoptions)).option_value::information_schema.character_data option_value
  FROM information_schema._pg_foreign_tables t;

ALTER TABLE foreign_table_options
    OWNER TO postgres;

GRANT SELECT ON foreign_table_options TO PUBLIC;

