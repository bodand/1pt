CREATE VIEW domain_constraints
            (constraint_catalog, constraint_schema, constraint_name, domain_catalog, domain_schema, domain_name,
             is_deferrable, initially_deferred)
AS
SELECT CURRENT_DATABASE()::information_schema.sql_identifier constraint_catalog
     , rs.nspname::information_schema.sql_identifier         constraint_schema
     , con.conname::information_schema.sql_identifier        constraint_name
     , CURRENT_DATABASE()::information_schema.sql_identifier domain_catalog
     , n.nspname::information_schema.sql_identifier          domain_schema
     , t.typname::information_schema.sql_identifier          domain_name
     , CASE
           WHEN con.condeferrable THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
    END::information_schema.yes_or_no                        is_deferrable
     , CASE
           WHEN con.condeferred THEN 'YES'::TEXT
           ELSE 'NO'::TEXT
    END::information_schema.yes_or_no                        initially_deferred
  FROM pg_namespace rs
     , pg_namespace n
     , pg_constraint con
     , pg_type t
 WHERE rs.oid = con.connamespace
   AND n.oid = t.typnamespace
   AND t.oid = con.contypid
   AND (PG_HAS_ROLE(t.typowner, 'USAGE'::TEXT) OR has_type_privilege(t.oid, 'USAGE'::TEXT));

ALTER TABLE domain_constraints
    OWNER TO postgres;

GRANT SELECT ON domain_constraints TO PUBLIC;

