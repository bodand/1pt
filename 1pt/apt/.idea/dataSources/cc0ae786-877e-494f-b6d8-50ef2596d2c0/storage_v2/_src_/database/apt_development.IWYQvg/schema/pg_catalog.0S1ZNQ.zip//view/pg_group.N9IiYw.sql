CREATE VIEW pg_group(groname, grosysid, grolist) AS
SELECT rolname                                              groname
     , oid                                                  grosysid
     , ARRAY(SELECT pg_auth_members.member
               FROM pg_auth_members
              WHERE pg_auth_members.roleid = pg_authid.oid) grolist
  FROM pg_authid
 WHERE NOT rolcanlogin;

ALTER TABLE pg_group
    OWNER TO postgres;

GRANT SELECT ON pg_group TO PUBLIC;

