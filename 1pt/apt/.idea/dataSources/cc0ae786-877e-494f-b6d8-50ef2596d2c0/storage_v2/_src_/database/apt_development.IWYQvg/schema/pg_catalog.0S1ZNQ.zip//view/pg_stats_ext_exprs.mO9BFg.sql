CREATE VIEW pg_stats_ext_exprs
            (schemaname, tablename, statistics_schemaname, statistics_name, statistics_owner, expr, inherited,
             null_frac, avg_width, n_distinct, most_common_vals, most_common_freqs, histogram_bounds, correlation,
             most_common_elems, most_common_elem_freqs, elem_count_histogram)
AS
SELECT cn.nspname                  schemaname
     , c.relname                   tablename
     , sn.nspname                  statistics_schemaname
     , s.stxname                   statistics_name
     , PG_GET_USERBYID(s.stxowner) statistics_owner
     , stat.expr
     , sd.stxdinherit              inherited
     , (stat.a).stanullfrac        null_frac
     , (stat.a).stawidth           avg_width
     , (stat.a).stadistinct        n_distinct
     , CASE
           WHEN (stat.a).stakind1 = 1 THEN (stat.a).stavalues1
           WHEN (stat.a).stakind2 = 1 THEN (stat.a).stavalues2
           WHEN (stat.a).stakind3 = 1 THEN (stat.a).stavalues3
           WHEN (stat.a).stakind4 = 1 THEN (stat.a).stavalues4
           WHEN (stat.a).stakind5 = 1 THEN (stat.a).stavalues5
           ELSE NULL::anyarray
    END                            most_common_vals
     , CASE
           WHEN (stat.a).stakind1 = 1 THEN (stat.a).stanumbers1
           WHEN (stat.a).stakind2 = 1 THEN (stat.a).stanumbers2
           WHEN (stat.a).stakind3 = 1 THEN (stat.a).stanumbers3
           WHEN (stat.a).stakind4 = 1 THEN (stat.a).stanumbers4
           WHEN (stat.a).stakind5 = 1 THEN (stat.a).stanumbers5
           ELSE NULL::REAL[]
    END                            most_common_freqs
     , CASE
           WHEN (stat.a).stakind1 = 2 THEN (stat.a).stavalues1
           WHEN (stat.a).stakind2 = 2 THEN (stat.a).stavalues2
           WHEN (stat.a).stakind3 = 2 THEN (stat.a).stavalues3
           WHEN (stat.a).stakind4 = 2 THEN (stat.a).stavalues4
           WHEN (stat.a).stakind5 = 2 THEN (stat.a).stavalues5
           ELSE NULL::anyarray
    END                            histogram_bounds
     , CASE
           WHEN (stat.a).stakind1 = 3 THEN (stat.a).stanumbers1[1]
           WHEN (stat.a).stakind2 = 3 THEN (stat.a).stanumbers2[1]
           WHEN (stat.a).stakind3 = 3 THEN (stat.a).stanumbers3[1]
           WHEN (stat.a).stakind4 = 3 THEN (stat.a).stanumbers4[1]
           WHEN (stat.a).stakind5 = 3 THEN (stat.a).stanumbers5[1]
           ELSE NULL::REAL
    END                            correlation
     , CASE
           WHEN (stat.a).stakind1 = 4 THEN (stat.a).stavalues1
           WHEN (stat.a).stakind2 = 4 THEN (stat.a).stavalues2
           WHEN (stat.a).stakind3 = 4 THEN (stat.a).stavalues3
           WHEN (stat.a).stakind4 = 4 THEN (stat.a).stavalues4
           WHEN (stat.a).stakind5 = 4 THEN (stat.a).stavalues5
           ELSE NULL::anyarray
    END                            most_common_elems
     , CASE
           WHEN (stat.a).stakind1 = 4 THEN (stat.a).stanumbers1
           WHEN (stat.a).stakind2 = 4 THEN (stat.a).stanumbers2
           WHEN (stat.a).stakind3 = 4 THEN (stat.a).stanumbers3
           WHEN (stat.a).stakind4 = 4 THEN (stat.a).stanumbers4
           WHEN (stat.a).stakind5 = 4 THEN (stat.a).stanumbers5
           ELSE NULL::REAL[]
    END                            most_common_elem_freqs
     , CASE
           WHEN (stat.a).stakind1 = 5 THEN (stat.a).stanumbers1
           WHEN (stat.a).stakind2 = 5 THEN (stat.a).stanumbers2
           WHEN (stat.a).stakind3 = 5 THEN (stat.a).stanumbers3
           WHEN (stat.a).stakind4 = 5 THEN (stat.a).stanumbers4
           WHEN (stat.a).stakind5 = 5 THEN (stat.a).stanumbers5
           ELSE NULL::REAL[]
    END                            elem_count_histogram
  FROM pg_statistic_ext s
           JOIN pg_class c ON c.oid = s.stxrelid
           LEFT JOIN pg_statistic_ext_data sd ON s.oid = sd.stxoid
           LEFT JOIN pg_namespace cn ON cn.oid = c.relnamespace
           LEFT JOIN pg_namespace sn ON sn.oid = s.stxnamespace
           JOIN LATERAL ( SELECT UNNEST(pg_get_statisticsobjdef_expressions(s.oid)) expr
                               , UNNEST(sd.stxdexpr)                                a) stat ON stat.expr IS NOT NULL;

ALTER TABLE pg_stats_ext_exprs
    OWNER TO postgres;

GRANT SELECT ON pg_stats_ext_exprs TO PUBLIC;

