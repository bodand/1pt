CREATE VIEW pg_stats_ext
            (schemaname, tablename, statistics_schemaname, statistics_name, statistics_owner, attnames, exprs, kinds,
             inherited, n_distinct, dependencies, most_common_vals, most_common_val_nulls, most_common_freqs,
             most_common_base_freqs)
AS
SELECT cn.nspname                                 schemaname
     , c.relname                                  tablename
     , sn.nspname                                 statistics_schemaname
     , s.stxname                                  statistics_name
     , PG_GET_USERBYID(s.stxowner)                statistics_owner
     , ( SELECT ARRAY_AGG(a.attname ORDER BY a.attnum) array_agg
           FROM UNNEST(s.stxkeys) k(k)
                    JOIN pg_attribute a ON a.attrelid = s.stxrelid AND a.attnum = k.k
       )                                          attnames
     , pg_get_statisticsobjdef_expressions(s.oid) exprs
     , s.stxkind                                  kinds
     , sd.stxdinherit                             inherited
     , sd.stxdndistinct                           n_distinct
     , sd.stxddependencies                        dependencies
     , m.most_common_vals
     , m.most_common_val_nulls
     , m.most_common_freqs
     , m.most_common_base_freqs
  FROM pg_statistic_ext s
           JOIN pg_class c ON c.oid = s.stxrelid
           JOIN pg_statistic_ext_data sd ON s.oid = sd.stxoid
           LEFT JOIN pg_namespace cn ON cn.oid = c.relnamespace
           LEFT JOIN pg_namespace sn ON sn.oid = s.stxnamespace
           LEFT JOIN LATERAL ( SELECT ARRAY_AGG(pg_mcv_list_items."values")       most_common_vals
                                    , ARRAY_AGG(pg_mcv_list_items.nulls)          most_common_val_nulls
                                    , ARRAY_AGG(pg_mcv_list_items.frequency)      most_common_freqs
                                    , ARRAY_AGG(pg_mcv_list_items.base_frequency) most_common_base_freqs
                                 FROM pg_mcv_list_items(sd.stxdmcv) pg_mcv_list_items(index, "values", nulls, frequency, base_frequency)) m
          ON sd.stxdmcv IS NOT NULL
 WHERE NOT (EXISTS ( SELECT 1
                       FROM UNNEST(s.stxkeys) k(k)
                                JOIN pg_attribute a ON a.attrelid = s.stxrelid AND a.attnum = k.k
                      WHERE NOT HAS_COLUMN_PRIVILEGE(c.oid, a.attnum, 'select'::TEXT)
                   ))
   AND (c.relrowsecurity = FALSE OR NOT row_security_active(c.oid));

ALTER TABLE pg_stats_ext
    OWNER TO postgres;

GRANT SELECT ON pg_stats_ext TO PUBLIC;

