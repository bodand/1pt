CREATE VIEW pg_locks
            (locktype, database, relation, page, tuple, virtualxid, transactionid, classid, objid, objsubid,
             virtualtransaction, pid, mode, granted, fastpath, waitstart)
AS
SELECT locktype
     , database
     , relation
     , page
     , tuple
     , virtualxid
     , transactionid
     , classid
     , objid
     , objsubid
     , virtualtransaction
     , pid
     , mode
     , granted
     , fastpath
     , waitstart
  FROM pg_lock_status() l(locktype, database, relation, page, tuple, virtualxid, transactionid, classid, objid,
                          objsubid, virtualtransaction, pid, mode, granted, fastpath, waitstart);

ALTER TABLE pg_locks
    OWNER TO postgres;

GRANT SELECT ON pg_locks TO PUBLIC;

