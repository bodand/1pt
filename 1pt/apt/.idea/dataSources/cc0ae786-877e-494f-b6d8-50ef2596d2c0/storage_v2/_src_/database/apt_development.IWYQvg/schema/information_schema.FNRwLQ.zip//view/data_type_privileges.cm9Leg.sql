CREATE VIEW data_type_privileges (object_catalog, object_schema, object_name, object_type, dtd_identifier) AS
SELECT CURRENT_DATABASE()::information_schema.sql_identifier object_catalog
     , objschema                                             object_schema
     , objname                                               object_name
     , objtype::information_schema.character_data            object_type
     , objdtdid                                              dtd_identifier
  FROM ( SELECT attributes.udt_schema
              , attributes.udt_name
              , 'USER-DEFINED TYPE'::TEXT text
              , attributes.dtd_identifier
           FROM information_schema.attributes
          UNION ALL
         SELECT columns.table_schema
              , columns.table_name
              , 'TABLE'::TEXT text
              , columns.dtd_identifier
           FROM information_schema.columns
          UNION ALL
         SELECT domains.domain_schema
              , domains.domain_name
              , 'DOMAIN'::TEXT text
              , domains.dtd_identifier
           FROM information_schema.domains
          UNION ALL
         SELECT parameters.specific_schema
              , parameters.specific_name
              , 'ROUTINE'::TEXT text
              , parameters.dtd_identifier
           FROM information_schema.parameters
          UNION ALL
         SELECT routines.specific_schema
              , routines.specific_name
              , 'ROUTINE'::TEXT text
              , routines.dtd_identifier
           FROM information_schema.routines
       ) x(objschema, objname, objtype, objdtdid);

ALTER TABLE data_type_privileges
    OWNER TO postgres;

GRANT SELECT ON data_type_privileges TO PUBLIC;

