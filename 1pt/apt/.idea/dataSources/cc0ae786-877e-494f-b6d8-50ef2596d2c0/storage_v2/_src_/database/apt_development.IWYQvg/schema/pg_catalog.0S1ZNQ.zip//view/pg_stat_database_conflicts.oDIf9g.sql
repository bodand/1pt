CREATE VIEW pg_stat_database_conflicts
            (datid, datname, confl_tablespace, confl_lock, confl_snapshot, confl_bufferpin, confl_deadlock,
             confl_active_logicalslot)
AS
SELECT oid                                           datid
     , datname
     , pg_stat_get_db_conflict_tablespace(oid)       confl_tablespace
     , pg_stat_get_db_conflict_lock(oid)             confl_lock
     , pg_stat_get_db_conflict_snapshot(oid)         confl_snapshot
     , pg_stat_get_db_conflict_bufferpin(oid)        confl_bufferpin
     , pg_stat_get_db_conflict_startup_deadlock(oid) confl_deadlock
     , pg_stat_get_db_conflict_logicalslot(oid)      confl_active_logicalslot
  FROM pg_database d;

ALTER TABLE pg_stat_database_conflicts
    OWNER TO postgres;

GRANT SELECT ON pg_stat_database_conflicts TO PUBLIC;

